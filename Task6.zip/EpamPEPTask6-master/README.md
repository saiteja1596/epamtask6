# EpamPEPTask6
Using lIst as Collections in Java
